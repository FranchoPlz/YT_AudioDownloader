//TODO: 
    Fix downloading pop up error -> not downloading while message is up
    Error handeling
//FUTURE FEATURES:
    Option for video download as well
    SUGESTIONS OPEN

to install use "python -m pip install git+https://github.com/FranchoPlz/YT_AudioDownloader.git"
to run double click launcher.bat

if installed in a virtual environment, use yt_audio_downloader to launch from the venv context