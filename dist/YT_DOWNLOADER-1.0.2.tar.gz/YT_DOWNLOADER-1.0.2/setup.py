from setuptools import setup
setup(install_requires=['PyQt5', 'pafy', 'youtube_dl'])
